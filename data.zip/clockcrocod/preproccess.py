from os.path import join, realpath, normpath
from os import isfile, dirpath, rename
import pandas as pd

dirname = dirpath("__main__")

df = pd.DataFrame()




